VENDAKZ — V1 COM UPLOAD REAL DE FOTOS

O que esta versão já faz:
- Criar conta e entrar com Supabase Auth
- Guardar utilizadores no Supabase
- Publicar produtos
- Escolher uma foto real no telemóvel
- Enviar a foto para Supabase Storage
- Guardar a URL da foto na tabela products
- Pesquisar produtos
- Mostrar preços em Kz
- Perfil e terminar sessão

PASSO 1 — CRIAR O PROJETO SUPABASE
1. Crie um projeto no Supabase.
2. Abra SQL Editor.
3. Execute primeiro o conteúdo de supabase_schema.sql.
4. Depois execute storage_product_images.sql.

PASSO 2 — CONFIGURAR A APLICAÇÃO
1. Duplique supabase-config.example.js.
2. Renomeie a cópia para supabase-config.js.
3. Coloque a URL do projeto e a chave Publishable/Anon.
4. NÃO coloque service_role/secret key no código do navegador.

PASSO 3 — TESTAR
Abra o index.html num ambiente que permita carregar os ficheiros JavaScript.
No telemóvel, é mais simples publicar o projeto num serviço de hospedagem de sites estáticos.

UPLOAD:
- JPG, PNG ou WEBP
- máximo 5 MB
- cada utilizador envia para a sua própria pasta
- o bucket product-images é público para que as fotos dos anúncios possam aparecer no marketplace.

IMPORTANTE:
Esta é uma versão MVP/educacional. Antes de colocar o marketplace em produção, ainda é recomendável adicionar validação mais forte, moderação, compressão de imagens, proteção contra spam, chat, favoritos, recuperação de palavra-passe e outras medidas de segurança.

IDADE E PAGAMENTOS:
Se algum serviço de hospedagem, pagamento ou conta exigir idade mínima, use a conta e a supervisão de um responsável de acordo com os termos do serviço. Não tente contornar limites de idade.
