let isSignup = false;
let session = null;

function $(id){ return document.getElementById(id); }
function showView(id){
  ["homeView","authView","sellView","profileView"].forEach(v => $(v).classList.add("hidden"));
  $(id).classList.remove("hidden");
}
function money(v){ return new Intl.NumberFormat("pt-AO").format(v) + " Kz"; }

async function waitForSupabase(){
  if (window.db) return;
  await new Promise(resolve => window.addEventListener("supabase-ready", resolve, {once:true}));
}

async function loadProducts(){
  const grid = $("productsGrid");
  grid.innerHTML = "<p>A carregar...</p>";
  const {data,error} = await window.db.from("products").select("*").order("created_at",{ascending:false});
  if(error){ grid.innerHTML = `<p class="error">${error.message}</p>`; return; }
  renderProducts(data || []);
}

function renderProducts(products){
  const q = $("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p => (p.name||"").toLowerCase().includes(q) || (p.location||"").toLowerCase().includes(q));
  $("productsGrid").innerHTML = filtered.length ? filtered.map(p => `
    <article class="card">
      ${p.image_url ? `<img src="${p.image_url}" alt="${escapeHtml(p.name)}">` : ""}
      <div class="card-body">
        <h3>${escapeHtml(p.name)}</h3>
        <div class="price">${money(p.price)}</div>
        <div class="muted">${escapeHtml(p.location||"")}</div>
        <p>${escapeHtml(p.description||"")}</p>
      </div>
    </article>`).join("") : "<p>Nenhum produto encontrado.</p>";
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

async function refreshSession(){
  await waitForSupabase();
  const result = await window.db.auth.getSession();
  session = result.data.session;
  updateAuthArea();
  if(session) loadProfile();
}

function updateAuthArea(){
  $("authArea").innerHTML = session
    ? `<button class="secondary" id="topSell">Vender</button>`
    : `<button class="secondary" id="topLogin">Entrar</button>`;
  if($("topSell")) $("topSell").onclick=()=>showView("sellView");
  if($("topLogin")) $("topLogin").onclick=()=>showView("authView");
}

async function loadProfile(){
  const {data} = await window.db.from("profiles").select("*").eq("id",session.user.id).maybeSingle();
  $("profileInfo").innerHTML = `<strong>${escapeHtml(data?.full_name || session.user.email)}</strong><br>${escapeHtml(session.user.email)}`;
}

document.addEventListener("DOMContentLoaded", async ()=>{
  await waitForSupabase();
  await refreshSession();
  await loadProducts();

  $("searchInput").addEventListener("input", loadProducts);
  $("refreshBtn").onclick = loadProducts;
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>{
    const v=b.dataset.view;
    if(v!=="homeView" && !session){ showView("authView"); return; }
    showView(v);
  });

  $("toggleAuth").onclick=()=>{
    isSignup=!isSignup;
    $("authTitle").textContent=isSignup?"Criar conta":"Entrar";
    $("authName").classList.toggle("hidden",!isSignup);
    $("toggleAuth").textContent=isSignup?"Já tenho conta":"Criar conta";
  };

  $("authForm").onsubmit=async e=>{
    e.preventDefault();
    $("authMessage").textContent="Aguarde...";
    const email=$("authEmail").value.trim();
    const password=$("authPassword").value;
    let result;
    if(isSignup){
      result=await window.db.auth.signUp({email,password,options:{data:{full_name:$("authName").value.trim()}}});
    }else{
      result=await window.db.auth.signInWithPassword({email,password});
    }
    if(result.error){ $("authMessage").textContent=result.error.message; $("authMessage").className="message error"; return; }
    $("authMessage").textContent=isSignup ? "Conta criada. Se necessário, confirme o email." : "Entrada realizada.";
    $("authMessage").className="message success";
    await refreshSession();
    showView("homeView");
  };

  $("sellForm").onsubmit=async e=>{
    e.preventDefault();
    if(!session){showView("authView");return;}
    const msg=$("sellMessage");
    const file=$("productImage").files[0];
    msg.textContent="A enviar a foto...";
    msg.className="message";
    try{
      const uploaded=await uploadProductImage(file,session.user.id);
      msg.textContent="A publicar produto...";
      const {error}=await window.db.from("products").insert({
        seller_id:session.user.id,
        name:$("productName").value.trim(),
        price:Number($("productPrice").value),
        location:$("productLocation").value.trim(),
        description:$("productDescription").value.trim(),
        image_url:uploaded.url
      });
      if(error) throw error;
      msg.textContent="Produto publicado com sucesso!";
      msg.className="message success";
      $("sellForm").reset();
      $("imagePreview").textContent="Pré-visualização da foto";
      await loadProducts();
      showView("homeView");
    }catch(err){
      msg.textContent=err.message || "Não foi possível publicar.";
      msg.className="message error";
    }
  };

  $("logoutBtn").onclick=async()=>{
    await window.db.auth.signOut();
    session=null;
    updateAuthArea();
    showView("homeView");
  };
});
