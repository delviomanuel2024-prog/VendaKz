if (!window.supabase) {
  console.error("Biblioteca Supabase não carregada.");
}
const SUPABASE_CDN = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
const script = document.createElement("script");
script.src = SUPABASE_CDN;
script.onload = () => {
  window.db = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
  window.dispatchEvent(new Event("supabase-ready"));
};
document.head.appendChild(script);
