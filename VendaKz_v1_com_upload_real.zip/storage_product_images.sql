-- Executar no SQL Editor do Supabase.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880,
        ARRAY['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "Public can view product images"
on storage.objects for select
using (bucket_id = 'product-images');

create policy "Users upload inside their own folder"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

create policy "Users update their own images"
on storage.objects for update
to authenticated
using (
  bucket_id = 'product-images'
  and owner_id = (select auth.uid()::text)
)
with check (
  bucket_id = 'product-images'
  and owner_id = (select auth.uid()::text)
);

create policy "Users delete their own images"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'product-images'
  and owner_id = (select auth.uid()::text)
);
