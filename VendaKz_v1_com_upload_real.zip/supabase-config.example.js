// Renomeie este arquivo para supabase-config.js e coloque os dados do seu projeto.
// Use APENAS a Publishable/Anon key no navegador. Nunca coloque a service_role/secret key.
window.SUPABASE_URL = "COLOQUE_AQUI_A_URL_DO_SUPABASE";
window.SUPABASE_ANON_KEY = "COLOQUE_AQUI_A_CHAVE_PUBLICAVEL";
