document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("productImage");
  const box = document.getElementById("imagePreview");
  if (!input || !box) return;
  input.addEventListener("change", () => {
    const file = input.files[0];
    if (!file) {
      box.textContent = "Pré-visualização da foto";
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      box.textContent = "Foto acima de 5 MB.";
      input.value = "";
      return;
    }
    const url = URL.createObjectURL(file);
    box.innerHTML = `<img src="${url}" alt="Pré-visualização">`;
  });
});
