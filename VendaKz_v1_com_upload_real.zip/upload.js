async function uploadProductImage(file, userId) {
  if (!file) throw new Error("Selecione uma foto.");
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) throw new Error("Use JPG, PNG ou WEBP.");
  if (file.size > 5 * 1024 * 1024) throw new Error("A foto deve ter no máximo 5 MB.");

  const ext = file.name.split(".").pop().toLowerCase();
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;

  const { error } = await window.db.storage
    .from("product-images")
    .upload(path, file, { contentType: file.type, upsert: false });

  if (error) throw error;

  const { data } = window.db.storage
    .from("product-images")
    .getPublicUrl(path);

  return { path, url: data.publicUrl };
}
